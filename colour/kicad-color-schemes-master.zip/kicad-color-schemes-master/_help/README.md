```kit-dev-coldfire-xilinx_5213``` is placed into this repository to have concistent screenshots of the different color schemes.
Please note this project was directly taken from the KiCad source tree:
[demos/kit-dev-coldfire-xilinx_5213](https://github.com/KiCad/kicad-source-mirror/tree/master/demos/kit-dev-coldfire-xilinx_5213)
